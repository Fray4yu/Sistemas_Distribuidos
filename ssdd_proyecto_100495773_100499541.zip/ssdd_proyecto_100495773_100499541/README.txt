1. Compilación con Makefile: make -f Makefile.rpc
2. En los terminales donde irán el servidor y el servidor-rpc: export LOG_RPC_IP=localhost
3. Terminal para servidor, ejecutar: ./servidor -p <puerto> (nosotros usabamos el 4000 por ejemplo)
4. Terminal para servidor-rpc, ejecutar: ./servidor_rpc
5. Terminal para servicio web, ejecutar: python3 web_service.py (o python, depende del sistema)
6. Terminal para cliente, ejecutar: python3 client.py -s <ip_servidor> <puerto> (o python, depende del sistema)
Para la ejecución del cliente, se deberá usar la ip del servidor, la cual se mostrará
en pantalla una vez este se ejecute en su terminal. El puerto también deberá ser el mismo que usa el
servidor.
 